@echo off
cd /d "%~dp0"
python --version >nul 2>&1
if errorlevel 1 goto missing
python -m venv .venv
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m playwright install chromium
if errorlevel 1 goto failed
echo Installation complete. Run start.cmd.
pause
exit /b 0
:missing
echo Install Python 3.11 or newer and enable Add Python to PATH.
pause
exit /b 1
:failed
echo Installation failed. Check the error above and your Internet connection.
pause
exit /b 1
