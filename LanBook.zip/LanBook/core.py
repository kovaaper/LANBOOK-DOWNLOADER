"""Save the document delivered by the current reader in the user's own session."""
import base64
import binascii
import io
import json
import re
import tempfile
import time
from pathlib import Path
from urllib.parse import urlsplit


class DownloadError(Exception):
    pass


def book_id(value):
    value = value.strip()
    if re.fullmatch(r"[1-9]\d*", value):
        return value
    url = urlsplit(value)
    match = re.fullmatch(r"/(?:reader/)?book/([1-9]\d*)/?", url.path)
    if (url.scheme != "https" or url.netloc not in ("e.lanbook.com", "reader.lanbook.com") or not match):
        raise DownloadError("Введите ссылку на книгу Лани или номер книги.")
    return match[1]


def endpoint(url, ident):
    parsed = urlsplit(url)
    if parsed.scheme != "https" or parsed.netloc != "reader.lanbook.com":
        return None
    prefix = f"/api/v2/book/{ident}/"
    if not parsed.path.startswith(prefix):
        return None
    suffix = parsed.path[len(prefix):].rstrip("/")
    return suffix if suffix in ("documentFile", "documentFile/preview", "metadata") else None


def check_status(status, stage="документ"):
    if status in (401, 403):
        raise DownloadError(f"{stage}: HTTP {status}. Проверьте вход и доступ к книге в читалке.")
    if status == 429:
        raise DownloadError(f"{stage}: HTTP 429. Сервер ограничил запросы; повторите позже.")
    if status != 200:
        raise DownloadError(f"{stage}: HTTP {status}. Сервер не выдал документ через текущий API.")


def decode_document(status, body):
    check_status(status)
    if body.startswith(b"%PDF-"):
        return body
    try:
        payload = json.loads(body)
        if not isinstance(payload, dict):
            raise ValueError()
        if payload.get("status") == "error":
            code = payload.get("code")
            if isinstance(code, int) and 400 <= code <= 599:
                check_status(code)
            raise DownloadError("API вернул ошибку вместо документа.")
        data = payload.get("data")
        if not isinstance(data, str):
            raise ValueError()
        pdf = base64.b64decode(data, validate=True)
        if not pdf.startswith(b"%PDF-"):
            raise ValueError()
        return pdf
    except (ValueError, TypeError, binascii.Error):
        raise DownloadError("Формат ответа изменился: ожидался PDF в поле data (base64).") from None


def capture_document(context, page, ident, cancel, report, timeout=120):
    # Only observe requests made by the reader. No copied tokens or fabricated API requests.
    result = {}
    failures = []

    def finished(request):
        kind = endpoint(request.url, ident)
        if not kind:
            return
        try:
            response = request.response()
            if response is None:
                return
            report("status", f"API: {kind}, HTTP {response.status}")
            if kind == "metadata":
                check_status(response.status, "метаданные книги")
            elif kind == "documentFile/preview":
                raise DownloadError("Читалка загрузила ознакомительный фрагмент. Откройте полную книгу в своём аккаунте.")
            else:
                result["pdf"] = decode_document(response.status, response.body())
        except DownloadError as exc:
            failures.append(str(exc))
        except Exception as exc:
            failures.append(f"Не удалось прочитать ответ читалки: {type(exc).__name__}.")

    def failed(request):
        kind = endpoint(request.url, ident)
        if kind:
            failures.append(f"Сетевой запрос {kind} прерван. Проверьте соединение и повторите загрузку.")

    context.on("requestfinished", finished)
    context.on("requestfailed", failed)
    try:
        report("status", "Ожидаю документ от читалки (до 120 секунд)…")
        parsed = urlsplit(page.url)
        if parsed.netloc == "reader.lanbook.com" and parsed.path.rstrip("/") == f"/book/{ident}":
            page.reload(wait_until="domcontentloaded", timeout=45000)
        else:
            page.goto(f"https://reader.lanbook.com/book/{ident}", wait_until="domcontentloaded", timeout=45000)
        deadline = time.monotonic() + timeout
        while "pdf" not in result:
            if cancel.is_set():
                raise DownloadError("Сохранение отменено.")
            if failures:
                raise DownloadError(failures[-1])
            if time.monotonic() >= deadline:
                raise DownloadError("Читалка не выдала PDF. В браузере откройте книгу для чтения, завершите вход и повторите сохранение. Если ошибка повторится, сообщите, что видно в читалке.")
            page.wait_for_timeout(100)
        if cancel.is_set():
            raise DownloadError("Сохранение отменено.")
        return result["pdf"]
    finally:
        context.remove_listener("requestfinished", finished)
        context.remove_listener("requestfailed", failed)


def save_document(data, start, end, destination, cancel, report):
    from pypdf import PdfReader, PdfWriter
    try:
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            raise DownloadError("Сервер выдал зашифрованный PDF; эта версия его не обрабатывает.")
        count = len(reader.pages)
    except DownloadError:
        raise
    except Exception:
        raise DownloadError("Полученный PDF повреждён или имеет неподдерживаемый формат.") from None
    end = count if end is None else end
    if not 1 <= start <= end <= count:
        raise DownloadError(f"В полученном документе {count} страниц. Проверьте диапазон {start}–{end}.")
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, suffix=".partial", delete=False) as out:
            temp = Path(out.name)
            if cancel.is_set():
                raise DownloadError("Сохранение отменено.")
            if start == 1 and end == count:
                # Preserve original PDF, including bookmarks, links and metadata.
                out.write(data)
                report("progress", (count, count, count))
            else:
                with PdfWriter() as writer:
                    for number in range(start - 1, end):
                        if cancel.is_set():
                            raise DownloadError("Сохранение отменено.")
                        writer.add_page(reader.pages[number])
                        report("progress", (number - start + 2, end - start + 1, number + 1))
                    writer.write(out)
        if cancel.is_set():
            raise DownloadError("Сохранение отменено.")
        temp.replace(target)
    finally:
        if temp and temp.exists():
            temp.unlink()
    return target
