import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk, font

from core import DownloadError, book_id, capture_document, save_document

BASE = Path(__file__).resolve().parent


class Worker(threading.Thread):
    def __init__(self, commands, events, cancel, shutdown):
        super().__init__(daemon=True)
        self.commands, self.events = commands, events
        self.cancel, self.shutdown = cancel, shutdown

    def report(self, kind, value):
        self.events.put((kind, value))

    def run(self):
        context = None
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as pw:
                try:
                    while not self.shutdown.is_set():
                        try:
                            action, args = self.commands.get(timeout=.1)
                        except queue.Empty:
                            if context:
                                try:
                                    if context.pages:
                                        context.pages[0].wait_for_timeout(50)
                                except Exception:
                                    context = None
                            continue
                        try:
                            if action == "open":
                                ident = args
                                if context:
                                    context.close()
                                    context = None
                                context = pw.chromium.launch_persistent_context(
                                    str(BASE / ".profile"), headless=False,
                                    viewport={"width": 1200, "height": 850})
                                page = context.pages[0] if context.pages else context.new_page()
                                page.goto(f"https://e.lanbook.com/book/{ident}", wait_until="domcontentloaded")
                                self.report("status", "Войдите в аккаунт в браузере. Затем нажмите «Скачать PDF».")
                            elif action == "download":
                                if not context or not context.pages:
                                    raise DownloadError("Сначала откройте браузер и войдите в аккаунт.")
                                ident, start, end, target = args
                                candidates = [p for p in context.pages if p.url.split("?")[0].rstrip("/") == f"https://reader.lanbook.com/book/{ident}"]
                                page = candidates[-1] if candidates else context.pages[0]
                                data = capture_document(context, page, ident, self.cancel, self.report)
                                result = save_document(data, start, end, target, self.cancel, self.report)
                                self.report("saved", str(result))
                        except DownloadError as exc:
                            self.report("error", str(exc))
                        except Exception as exc:
                            # Do not log network bodies, URLs containing tokens or session data.
                            self.report("error", f"Ошибка {type(exc).__name__}. Проверьте соединение и откройте книгу в браузере. При повторении ошибки сообщите её тип и содержимое экрана читалки.")
                        finally:
                            self.report("idle", None)
                finally:
                    if context:
                        context.close()
        except Exception as exc:
            self.report("error", f"Не удалось запустить браузер: {type(exc).__name__}. Выполните bash install.sh.")
            self.report("dead", None)


def main():
    try:
        root = tk.Tk()
    except tk.TclError:
        raise SystemExit("Не удалось открыть окно. Запустите bash start.sh из графического рабочего стола Linux (X11/XWayland).") from None
    root.title("Лань → PDF · 2.1 Linux")
    root.geometry("700x370")
    root.minsize(620, 370)
    commands, events = queue.Queue(), queue.Queue()
    cancel, shutdown = threading.Event(), threading.Event()
    worker = Worker(commands, events, cancel, shutdown)
    frame = ttk.Frame(root, padding=22)
    frame.pack(fill="both", expand=True)
    title_font = font.nametofont("TkDefaultFont").copy()
    title_font.configure(size=20, weight="bold")
    ttk.Label(frame, text="Лань → PDF", font=title_font).pack(anchor="w")
    ttk.Label(frame, text="Войдите в свой аккаунт и сохраните доступные страницы книги.").pack(anchor="w", pady=(4, 18))
    url = tk.StringVar(value="https://e.lanbook.com/book/427580")
    ttk.Entry(frame, textvariable=url).pack(fill="x")
    row = ttk.Frame(frame)
    row.pack(fill="x", pady=14)
    ttk.Label(row, text="С страницы:").pack(side="left")
    first = tk.StringVar(value="1")
    ttk.Entry(row, textvariable=first, width=7).pack(side="left", padx=8)
    ttk.Label(row, text="По:").pack(side="left")
    last = tk.StringVar()
    ttk.Entry(row, textvariable=last, width=7).pack(side="left", padx=8)
    ttk.Label(row, text="пусто — все страницы PDF").pack(side="left")
    buttons = ttk.Frame(frame)
    buttons.pack(fill="x", pady=5)
    status = tk.StringVar(value="Нажмите «Войти в аккаунт», затем выполните вход в открывшемся браузере.")
    progress = ttk.Progressbar(frame, mode="determinate")

    def busy(value):
        if shutdown.is_set():
            for button in (login, save, stop):
                button.configure(state="disabled")
            return
        login.configure(state="disabled" if value else "normal")
        save.configure(state="disabled" if value else "normal")
        stop.configure(state="normal" if value else "disabled")

    def submit(action):
        if shutdown.is_set():
            return
        try:
            ident = book_id(url.get())
            args = ident
            if action == "download":
                start = int(first.get())
                end = int(last.get()) if last.get().strip() else None
                if start < 1 or start > 20000 or (end is not None and (end < start or end > 20000)):
                    raise ValueError()
                target = filedialog.asksaveasfilename(defaultextension=".pdf",
                    initialfile=f"lanbook-{ident}.pdf", filetypes=[("PDF", "*.pdf")])
                if not target:
                    return
                args = (ident, start, end, target)
            cancel.clear()
            progress["value"] = 0
            busy(True)
            status.set("Открываю браузер…" if action == "open" else "Ожидаю PDF от читалки…")
            commands.put((action, args))
        except DownloadError as exc:
            messagebox.showerror("Проверьте ссылку", str(exc))
        except ValueError:
            messagebox.showerror("Диапазон", "Укажите целые номера страниц от 1 до 20000; конец не меньше начала.")

    login = ttk.Button(buttons, text="1. Войти в аккаунт", command=lambda: submit("open"))
    login.pack(side="left")
    save = ttk.Button(buttons, text="2. Скачать PDF", command=lambda: submit("download"))
    save.pack(side="left", padx=8)
    stop = ttk.Button(buttons, text="Остановить", command=cancel.set, state="disabled")
    stop.pack(side="left")
    progress.pack(fill="x", pady=16)
    ttk.Label(frame, textvariable=status, wraplength=640).pack(anchor="w")

    def poll():
        while True:
            try:
                kind, value = events.get_nowait()
            except queue.Empty:
                break
            if shutdown.is_set():
                continue
            if kind == "idle":
                busy(False)
            elif kind == "dead":
                login.configure(state="disabled")
                save.configure(state="disabled")
                stop.configure(state="disabled")
            elif kind == "progress":
                count, total, number = value
                progress.configure(maximum=total, value=count)
                status.set(f"Страница {number}: готово {count} из {total}")
            elif kind == "saved":
                status.set(f"Готово: {value}")
                messagebox.showinfo("PDF сохранён", value)
            else:
                status.set(value)
        root.after(100, poll)

    def close():
        if shutdown.is_set():
            return
        cancel.set()
        shutdown.set()
        busy(True)
        status.set("Завершаю работу и закрываю браузер…")

        def finish():
            if worker.is_alive():
                root.after(150, finish)
            else:
                root.destroy()
        finish()

    root.protocol("WM_DELETE_WINDOW", close)
    worker.start()
    poll()
    root.mainloop()


if __name__ == "__main__":
    main()
