#!/usr/bin/env bash
set -Eeuo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if (( EUID == 0 )); then
    echo "Запускайте программу от обычного пользователя, без sudo."
    exit 1
fi
if [[ ! -x .venv/bin/python ]]; then
    echo "Сначала выполните: bash install.sh"
    exit 1
fi
if [[ -z "${DISPLAY:-}" ]]; then
    echo "Нет графического дисплея DISPLAY. Запустите из рабочего стола Linux."
    echo "Для Wayland нужен включённый XWayland (интерфейс Tk использует X11)."
    exit 1
fi
umask 077
mkdir -p .profile
chmod 700 .profile
exec .venv/bin/python app.py
