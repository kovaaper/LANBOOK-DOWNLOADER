#!/usr/bin/env bash
set -Eeuo pipefail
trap 'printf "\nУстановка прервана. Исправьте ошибку выше и повторите bash install.sh\n" >&2' ERR
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

if (( EUID == 0 )); then
    echo "Запускайте bash install.sh от обычного пользователя, без sudo."
    exit 1
fi
if [[ ! -r /etc/os-release ]]; then
    echo "Не удалось определить дистрибутив Linux. См. README.md."
    exit 1
fi
source /etc/os-release
case "${ID:-}:${VERSION_ID:-}" in
    ubuntu:24.04|ubuntu:26.04|debian:12|debian:13) ;;
    *) echo "Автоустановка рассчитана на Ubuntu 24.04/26.04 и Debian 12/13. См. README.md."; exit 1 ;;
esac
case "$(uname -m)" in
    x86_64|aarch64|arm64) ;;
    *) echo "Нужен 64-битный Linux x86_64 или ARM64."; exit 1 ;;
esac
if ! command -v sudo >/dev/null; then
    echo "Не найден sudo. Попросите администратора установить системные зависимости из README.md."
    exit 1
fi
echo "Устанавливаю Python, Tk и зависимости браузера. sudo может запросить пароль Linux."
sudo apt-get update
sudo apt-get install -y python3 python3-venv python3-tk
python3 -c 'import sys; assert sys.version_info >= (3, 11), "Нужен Python 3.11+"'
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m playwright install --with-deps chromium
echo "Готово. Для запуска: bash start.sh"
