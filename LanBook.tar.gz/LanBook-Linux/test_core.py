import base64
import io
import json
import tempfile
import threading
import unittest
import errno
from unittest.mock import Mock, patch
from pathlib import Path

from playwright.sync_api import sync_playwright
from pypdf import PdfReader, PdfWriter
from core import DownloadError, book_id, capture_document, decode_document, endpoint, save_document


def sample_pdf():
    out = io.BytesIO()
    with PdfWriter() as writer:
        for width in (100, 200, 300):
            writer.add_blank_page(width=width, height=400)
        writer.write(out)
    return out.getvalue()


class CoreTests(unittest.TestCase):
    def test_malformed_link(self):
        with self.assertRaises(DownloadError):
            book_id('https://[invalid/book/1')

    def test_cancel_before_navigation(self):
        page = Mock()
        cancel = threading.Event()
        cancel.set()
        with self.assertRaisesRegex(DownloadError, 'отменено'):
            capture_document(Mock(), page, '1', cancel, Mock())
        page.goto.assert_not_called()
        page.reload.assert_not_called()

    def test_old_request_failure_ignored_and_listeners_removed(self):
        page = Mock()
        page.url = 'about:blank'
        handlers = {}
        page.on.side_effect = lambda name, callback: handlers.update({name: callback})
        old = Mock(url='https://reader.lanbook.com/api/v2/book/1/documentFile')
        current = Mock(url=old.url)
        current.response.return_value = Mock(status=200)
        current.response.return_value.body.return_value = sample_pdf()
        def navigate(*args, **kwargs):
            handlers['requestfailed'](old)
            handlers['request'](current)
            handlers['requestfinished'](current)
        page.goto.side_effect = navigate
        context = Mock()
        self.assertEqual(capture_document(context, page, '1', threading.Event(), Mock()), sample_pdf())
        context.on.assert_not_called()
        self.assertEqual(page.remove_listener.call_count, 3)

    def test_timeout_cleans_up_listeners(self):
        page = Mock(url='about:blank')
        with self.assertRaisesRegex(DownloadError, 'не выдала PDF'):
            capture_document(Mock(), page, '1', threading.Event(), Mock(), timeout=0)
        self.assertEqual(page.remove_listener.call_count, 3)

    def test_disk_full_preserves_existing_file(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / 'book.pdf'
            target.write_bytes(b'previous')
            with patch('core.tempfile.NamedTemporaryFile', side_effect=OSError(errno.ENOSPC, 'disk full')):
                with self.assertRaisesRegex(DownloadError, 'недостаточно'):
                    save_document(sample_pdf(), 1, None, target, threading.Event(), Mock())
            self.assertEqual(target.read_bytes(), b'previous')

    def test_replace_denied_cleans_temporary_file(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / 'book.pdf'
            target.write_bytes(b'previous')
            with patch('core.Path.replace', side_effect=PermissionError('denied')):
                with self.assertRaisesRegex(DownloadError, 'Нет доступа'):
                    save_document(sample_pdf(), 1, None, target, threading.Event(), Mock())
            self.assertEqual(target.read_bytes(), b'previous')
            self.assertFalse(list(Path(folder).glob('*.partial')))

    def test_urls(self):
        self.assertEqual(book_id('https://reader.lanbook.com/book/427580'), '427580')
        for url in ['https://e.lanbook.com.evil/book/1', 'https://user@e.lanbook.com/book/1', 'http://e.lanbook.com/book/1', '0']:
            with self.assertRaises(DownloadError):
                book_id(url)
        self.assertEqual(endpoint('https://reader.lanbook.com/api/v2/book/1/documentFile?jwtToken=secret', '1'), 'documentFile')
        self.assertIsNone(endpoint('https://evil.com/api/v2/book/1/documentFile', '1'))
        self.assertIsNone(endpoint('https://reader.lanbook.com/api/v2/book/2/documentFile', '1'))

    def test_decode_actual_schema(self):
        pdf = sample_pdf()
        body = json.dumps({'status': 'success', 'data': base64.b64encode(pdf).decode()}).encode()
        self.assertEqual(decode_document(200, body), pdf)
        self.assertEqual(decode_document(200, pdf), pdf)

    def test_errors_no_secrets(self):
        for status in [400, 401, 403, 429, 500]:
            with self.assertRaises(DownloadError) as exc:
                decode_document(status, b'secret server data')
            self.assertNotIn('secret', str(exc.exception))
        for body in [b'<html>login</html>', b'{}', b'[]', b'{"data":"oops"}', b'{"status":"error","code":403}']:
            with self.assertRaises(DownloadError):
                decode_document(200, body)

    def test_original_and_range(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / 'book.pdf'
            pdf = sample_pdf()
            save_document(pdf, 1, None, target, threading.Event(), lambda *x: None)
            self.assertEqual(target.read_bytes(), pdf)
            save_document(pdf, 2, 3, target, threading.Event(), lambda *x: None)
            pages = PdfReader(target).pages
            self.assertEqual(len(pages), 2)
            self.assertEqual([float(p.mediabox.width) for p in pages], [200, 300])

    def test_invalid_range_and_cancel_preserve_output(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder) / 'book.pdf'
            target.write_bytes(b'previous file')
            with self.assertRaises(DownloadError):
                save_document(sample_pdf(), 1, 4, target, threading.Event(), lambda *x: None)
            cancel = threading.Event()
            with self.assertRaises(DownloadError):
                save_document(sample_pdf(), 1, 2, target, cancel, lambda *x: cancel.set())
            self.assertEqual(target.read_bytes(), b'previous file')
            self.assertFalse(list(Path(folder).glob('*.partial')))


class BrowserTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pw = sync_playwright().start()
        cls.browser = cls.pw.chromium.launch()

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.pw.stop()

    def scenario(self, status=200, kind='documentFile'):
        pdf = sample_pdf()
        body = json.dumps({'status': 'success', 'data': base64.b64encode(pdf).decode()})
        context = self.browser.new_context()
        messages = []
        def route(req):
            if '/api/' in req.request.url:
                req.fulfill(status=status, content_type='application/json', body=body)
            else:
                req.fulfill(content_type='text/html', body=f'<script>fetch("/api/v2/book/1/{kind}?base64=1&jwtToken=test-secret").then(r=>r.json())</script>')
        context.route('**/*', route)
        try:
            result = capture_document(context, context.new_page(), '1', threading.Event(), lambda k,v: messages.append(str(v)), timeout=3)
            self.assertFalse(any('test-secret' in m for m in messages))
            return result, pdf
        finally:
            context.close()

    def test_browser_current_api(self):
        result, pdf = self.scenario()
        self.assertEqual(result, pdf)

    def test_browser_denied(self):
        with self.assertRaisesRegex(DownloadError, '403'):
            self.scenario(status=403)

    def test_browser_preview(self):
        with self.assertRaisesRegex(DownloadError, 'ознакомительный'):
            self.scenario(kind='documentFile/preview')


if __name__ == '__main__':
    unittest.main()
